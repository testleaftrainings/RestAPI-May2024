package Validation;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class CreateIncident_ValidateSchema {
	
	@Test
	public void createNewIncident() {
		
		File schema = new File("./src/main/resources/CreateIncidentSchema.json");
		
		//step1: Setup the endpoint
		RestAssured.baseURI ="https://dev254468.service-now.com/api/now/table/incident";
		//step2: Setup the authentication
		RestAssured.authentication = RestAssured.basic("admin", "India@123");
		
		//step3: place the request
		
		Response response = RestAssured
		.given()
		//.queryParam("sysparm_fields", "number,sys_id,short_description")
		.contentType("application/json")
		.body("{\"short_description\":\"created using RestAssured\"}")
		.when()
		.post();
		
		response.then().assertThat().body(JsonSchemaValidator.matchesJsonSchema(schema));
		

	}

}
