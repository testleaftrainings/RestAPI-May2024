package week3.day2;

import java.util.List;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class GetAllIncidents {
	
	@Test
	public void createNewIncident() {
		//step1: Setup the endpoint
		RestAssured.baseURI ="https://dev254468.service-now.com/api/now/table/incident";
		//step2: Setup the authentication
		RestAssured.authentication = RestAssured.basic("admin", "India@123");
		
		//step3: place the request
		Response response = RestAssured
		.given()
		.queryParam("sysparm_fields", "number,sys_id,short_description")
		.queryParam("sysparm_limit", "5")
		.when()
		.get();
		
		
		//convert the response into readable json format
		JsonPath resp = response.jsonPath();
		
		List<String> listNumbers = resp.getList("result.number"); //all 85 numbers
		List<String> listSD = resp.getList("result.short_description"); //all 85 SD
		
		for (int i = 0; i < listNumbers.size(); i++) {
			if(listSD.get(i).equals("Create using RestAssured"))
				System.out.println(listNumbers.get(i));
		}
		
		
		
		
		
		
		
		
		
		
		/*
		 * System.out.println(listNumbers.size());
		 * System.out.println("*********************");
		 * System.out.println(listNumbers.get(0));
		 * System.out.println("*********************"); for (String eachNumber :
		 * listNumbers) { System.out.println(eachNumber); }
		 */
		
		
		
		
		

	}

}
