package steps;


import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.equalTo;

import java.io.File;
import java.util.Map;
import java.util.Map.Entry;

import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.apache.commons.lang3.StringUtils;

import hooks.SetUp;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class IncidentManagement extends Common{
	
	

	@Given("Set the endpoint")
	public  void SetEndpoint() {
		RestAssured.baseURI="https://dev140572.service-now.com/api/now/table/";
	}
	
	@And("Set the Auth")
	public void setAuth() {
		RestAssured.authentication=RestAssured.basic("admin", "P-qQ7@umSYz8");
	}
	
	@When("get incidents")
	public void getIncidents() {
		
		inputRequest = RestAssured.given().log().all();
		response = inputRequest.get("incident");
	}
	
	@Then("validate response code as {int}")
	public void validateRespons(int responseCode) {
		
		response.then().assertThat().statusCode(responseCode);
		//response.prettyPrint();
	}
	
	@When("create incident with String body {string}")
	public void createIncident(String body) {
	
		inputRequest = RestAssured.given().contentType("application/json").body(body);
		response = inputRequest.post("incident");
		//response.prettyPrint();
	}
	
	@When("get incidents with queryparam {string} and {string}")
	public void getIncidentQP(String key, String value) {
		
		inputRequest = RestAssured.given().queryParam(key, value);
		response = inputRequest.get("incident");
	}
	
	@When("create incident with file {string}")
	public void createIncidentFile(String fileName) {
		
		File file =new File ("./data/"+fileName);
		inputRequest = RestAssured.given().contentType("application/json").body(file);
		response = inputRequest.post("incident");
		
		
	}	


}


