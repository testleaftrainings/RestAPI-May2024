package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/test/java/features",
				 glue = "steps",
				 monochrome = true,
				 publish = true,
				 //tags = "@change" -> to execute a specific feature file which contains that tag
				// tags = "not @incident" -> to exclude particular tag for execution
				// tags = "@incident or @change" -> either one tag is enough for eligibility
				 tags = "@regression"
				 )
public class CucumberRunner extends AbstractTestNGCucumberTests{

}
