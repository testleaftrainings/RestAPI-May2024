package steps;

import java.io.File;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class StepDefinition {
	
	public static RequestSpecification reqSpec;
	public static Response response;

	@Given("Setup endpoint")
	public void setupEndpoint() {
		RestAssured.baseURI ="https://dev254468.service-now.com/api/now/table/incident";
	}

	@Given("Setup the basic authentication")
	public void setupAuth() {
		RestAssured.authentication = RestAssured.basic("admin", "India@123");
	}

	@Given("Configure the header")
	public void configHeader() {
		reqSpec = RestAssured.given().log().all().contentType("application/json");
	}

	@Given("Configure the body with file {string}")
	public void configBody(String fileName) {
		File file = new File("./data/"+fileName);
		reqSpec = reqSpec.body(file);
	}

	@When("Place the request using post method")
	public void placePostRequest() {
		response = reqSpec.when().post();
		response.prettyPrint();
	}

	@Then("Verify the status code as {int}")
	public void verifyStatusCode(int statusCode) {
		response.then().assertThat().statusCode(statusCode);
	}

}
