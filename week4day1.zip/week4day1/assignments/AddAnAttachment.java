package week3.assignments;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class AddAnAttachment {
	
	@Test
	public void createNewIncident() {
		//step1: Setup the endpoint
		RestAssured.baseURI ="https://testleaf-trainings.atlassian.net/rest/api/2/issue/RA-4/attachments";
		//step2: Setup the authentication
		RestAssured.authentication = RestAssured.preemptive().basic("testleaf.trainings@testleaf.com", "ATATT3xFfGF0l2KVOZTGbR_0VQBlvxI_v-rTlZBjmN4jmtxKKqXkt1skQaS39YRDL9D245KzAyn9VWZf99qZ3tKpCvroD8h2kHSk3xLBTdecHB_J90rWqN00fFe_ahe6H_CA-0a4whxgSybsLENVCXZmjNl52pOx1nVdqGX83r-n5bEL88Z_zcU=7CE54054");
		
		//step3: place the request
		
		Response response = RestAssured
		.given()
		.header("X-Atlassian-Token","no-check")
		.contentType("multipart/form-data")
		.multiPart(new File("./data/RA_4.png"))
		.when()
		.post();
		
		response.prettyPrint();
			

	}

}
