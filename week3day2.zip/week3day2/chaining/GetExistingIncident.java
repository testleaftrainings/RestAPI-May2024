package chaining;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class GetExistingIncident extends BaseClass{
							  //packageName.ClassName.methodName
	@Test(dependsOnMethods = "chaining.CreateIncident.createNewIncident")
	public void getAnIncident() {
				
		
		Response response = RestAssured
		.given()
		.log()
		.all()
		.queryParam("sysparm_fields", "number,sys_id,short_description")
		.when()
	//	.get("/"+sysId);
		.get();
		
		response.then().assertThat().body("result.number", Matchers.hasItem(incidentNumber));
		
		response.prettyPrint();
		
		
		

	}

}
