package chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class CreateIncident extends BaseClass {
	
	@Test
	public void createNewIncident() {
					
		Response response = RestAssured
		.given()
		.log()
		.all()
		.queryParam("sysparm_fields", "number,sys_id,short_description")
		.contentType("application/json")
		.body("{\"short_description\":\"created using RestAssured\"}")
		.when()
		.post();
		
		response.prettyPrint();
		
		//convert the response into readable json format
		JsonPath resp = response.jsonPath();
		
		sysId = resp.get("result.sys_id");
		incidentNumber = resp.get("result.number");
	

	}

}
