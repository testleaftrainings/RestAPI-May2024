package chaining;

import org.testng.annotations.BeforeMethod;

import io.restassured.RestAssured;

public class BaseClass {
	
	public static String sysId;
	public static String incidentNumber;

	@BeforeMethod
	public void preCondition() {
		// step1: Setup the endpoint
		RestAssured.baseURI = "https://dev254468.service-now.com/api/now/table/incident";
		// step2: Setup the authentication
		RestAssured.authentication = RestAssured.basic("admin", "India@123");

	}

}
