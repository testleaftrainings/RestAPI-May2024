package steps;

import io.cucumber.java.Before;
import io.restassured.RestAssured;

public class HooksImplementation {
	
	@Before
	public void preCondition() {
		RestAssured.baseURI ="https://dev254468.service-now.com/api/now/table/";
		RestAssured.authentication = RestAssured.basic("admin", "India@123");

	}

}
