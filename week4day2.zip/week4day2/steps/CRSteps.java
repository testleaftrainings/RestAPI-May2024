package steps;

import java.io.File;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CRSteps extends BaseClass{
	
	
	@Given("Configure the necessary query parameter")
	public void configureQueryParam() {
		reqSpec = RestAssured.given().log().all()
				.queryParam("sysparm_limit", "3")
				.queryParam("sysparm_fields", "number,sys_id,short_description");

	}
	
	@When("Place the request using get method with table as {string}")
	public void placeGetRequest(String tableName) {
		response = reqSpec.when().get(tableName);
		response.prettyPrint();
	}
	
	
}
