package Validation;

import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;

public class CreateIncident_ValidateBody {

	@Test
	public void createNewIncident() {
		// step1: Setup the endpoint
		RestAssured.baseURI = "https://dev254468.service-now.com/api/now/table/incident";
		// step2: Setup the authentication
		RestAssured.authentication = RestAssured.basic("admin", "India@123");

		// step3: place the request

		Response response = RestAssured.given() // preCondition
				.queryParam("sysparm_fields", "number,sys_id,short_description").contentType("application/json")
				.body("{\"short_description\":\"created using RestAssured\"}").when() // test condition
				.post();

		// exact validation
		response.then().assertThat().body("result.short_description", Matchers.equalTo("created using RestAssured"));
		
		//partial validation
		response.then().assertThat().body("result.short_description", Matchers.containsString("RestAssured"));

		// ExtractableResponse<Response> response = vResp.extract();

		// int statusCode = response.getStatusCode();

		// Assert.assertEquals(statusCode, 200);

		/*
		 * if(statusCode == 201)
		 * System.out.println("Status code is matching with expected value"); else
		 * System.out.println("Status code is not matching with expected value");
		 */

	}

}
