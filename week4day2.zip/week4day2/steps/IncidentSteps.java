package steps;

import java.io.File;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class IncidentSteps extends BaseClass{
	

	/*
	 * @Given("Setup endpoint") public void setupEndpoint() { RestAssured.baseURI
	 * ="https://dev254468.service-now.com/api/now/table/"; }
	 * 
	 * @Given("Setup the basic authentication") public void setupAuth() {
	 * RestAssured.authentication = RestAssured.basic("admin", "India@123"); }
	 */

	@Given("Configure the header")
	public void configHeader() {
		reqSpec = RestAssured.given().log().all().contentType("application/json");
	}

	@Given("Configure the body with file {string}")
	public void configBody(String fileName) {
		File file = new File("./data/"+fileName);
		reqSpec = reqSpec.body(file);
	}

	@When("Place the request using post method with table as {string}")
	public void placePostRequest(String tableName) {
		response = reqSpec.when().post(tableName);
		response.prettyPrint();
	}

	@Then("Verify the status code as {int}")
	public void verifyStatusCode(int statusCode) {
		response.then().assertThat().statusCode(statusCode);
	}
	
	
	
	
	
}
