package week3.day2;

import java.util.List;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class GetAllCR {
	
	@Test
	public void getAllCR() {
		//step1: Setup the endpoint
		RestAssured.baseURI ="https://dev254468.service-now.com/api/now/table/change_request";
		//step2: Setup the authentication
		RestAssured.authentication = RestAssured.basic("admin", "India@123");
		
		//step3: place the request
		Response response = RestAssured
		.given()
		.log()
		.all()
		.when()
		.get();
		
		//convert the response into readable json format
		JsonPath resp = response.jsonPath();
		List<String> listNumbers = resp.getList("result.number"); //all 85 numbers
		List<String> listState = resp.getList("result.state"); //all 85 SD
		
		int count=0;
		for (int i = 0; i < listNumbers.size(); i++) {
			if(listState.get(i).equals("-5")) {
				System.out.println(listNumbers.get(i));
				count++;
			}
		}
		
		System.out.println("Total number of CR with the matching State: "+count);


	}

}
