package week3.day2;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class CreateIncident {
	
	@Test
	public void createNewIncident() {
		//step1: Setup the endpoint
		RestAssured.baseURI ="https://dev254468.service-now.com/api/now/table/incident";
		//step2: Setup the authentication
		RestAssured.authentication = RestAssured.basic("admin", "India@123");
		
		//step3: place the request
		
		Response response = RestAssured
		.given()
		.queryParam("sysparm_fields", "number,sys_id,short_description")
		.contentType("application/json")
		.body("{\"short_description\":\"created using RestAssured\"}")
		.when()
		.post();
		
		response.prettyPrint();
		
		//convert the response into readable json format
		JsonPath resp = response.jsonPath();
		
		String INCNumber = resp.get("result.number");
		System.out.println(INCNumber);

		

	}

}
